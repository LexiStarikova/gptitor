import './notstudymode.css';

const notstudymode = () => {
    return (
        <div></div>
    );
  };
  
  export default notstudymode;