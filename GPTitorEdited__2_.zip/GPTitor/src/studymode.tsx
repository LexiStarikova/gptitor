import './studymode.css';

const studymode = () => {
    return (
        <div></div>
    );
  };
  
  export default studymode;